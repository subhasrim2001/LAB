#include<stdio.h>
#include<ctype.h>
void main()
{
    int i;
    char s[50];
    printf("\nEnter string:");
    scanf("%s", s);
    for(i=0; s[i]!='\0'; i++)
    {
        if(isupper(s[i]))
        {
            s[i]=tolower(s[i]);
        }
        else if(islower(s[i]))
        {
            s[i]=toupper(s[i]);
        }
    }
    printf("\nNew string:%s", s);
}
