#include<stdio.h>
void main()
{
    char s1[20], s2[20], ch;
    int i, j, k;
    printf("\nEnter string 1:");
    scanf("%s", s1);
    printf("\nEnter string 2:");
    scanf("%s", s2);
    for(i=0; s1[i]!='\0'; i++)
    {
        ch=s1[i];
        for(j=0; s2[j]!='\0'; j++)
        {
            if(s2[j]==ch)
            {
                for(k=j-1; s2[k]!='\0'; k++)
                {
                    s2[k]=s2[k+1];
                }
            }
        }
    }
    printf("\nNew string 2:%s", s2);
}
