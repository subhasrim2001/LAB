/*to be done*/
#include<stdio.h>
void main()
{
    int i, j, f=0, l;
    char s[50], w[20];
    printf("\nEnter string:");
    scanf("%s", s);
    printf("\nEnter word:");
    scanf("%*c%s", s);
    l=strlen(w);
    for(i=0; s[i]!='\0'; i++)
    {
        f=0;
        if(s[i]==w[0])
        {
            for(j=0; w[j]!='\0'; j++)
            {
                if(s[i+j]!=w[j])
                {
                    f=1;
                    break;
                }
                if(f==0)
                {
                    for(j=i; s[j+l]!='\0'; j++)
                    {
                        s[j]=s[j+l];
                        printf("(%c,%c)", s[j], s[j+l]);
                    }
                    s[j]='\0';
                }
            }
        }
    }
    printf("\nNew string:%s\n", s);
}
