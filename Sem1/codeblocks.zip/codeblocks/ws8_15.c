#include<stdio.h>
void main()
{
    int i, f=0, j;
    char s[50], sub[20];
    printf("\nEnter string:");
    scanf("%s", s);
    printf("\nEnter substring:");
    scanf("%*c%s", sub);
    for(i=0; s[i]!='\0'; i++)
    {
        if(s[i]==sub[0])
        {
            for(j=0; sub[j]!='\0'; j++)
            {
                if(s[i+j]!=sub[j])
                {
                    break;
                }
            }
            if(sub[j]=='\0')
            {
                f=1;
                printf("\nSubstring found at index %d\n", i);
                break;
            }
        }
    }
    if(!f)
    {
        printf("\nSubstring not found\n");
    }
}
