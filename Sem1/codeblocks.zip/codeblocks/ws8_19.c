#include<stdio.h>
void main()
{
    int a, b, i, j, k;
    char s[20], ch;
    printf("\nEnter string:");
    scanf("%[^\n]", s);
    for(i=0; s[i]!='\0'; i++);
    s[i]=' ';
    s[i+1]='\0';
    a=0;
    for(i=0; s[i]!='\0'; i++)
    {
        if(s[i]==' ')
        {
            b=i-1;
            for(j=a, k=b; j<a+((b-a)/2)+1; j++, k--)
            {
                ch=s[j];
                s[j]=s[k];
                s[k]=ch;
            }
            a=i+1;
        }
    }
    printf("\nNew string:%s\n", s);
}
