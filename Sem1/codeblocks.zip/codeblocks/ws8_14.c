#include<stdio.h>
void main()
{
    char s[50], ch;
    int i, j;
    printf("\nEnter string:");
    scanf("%s", s);
    printf("\nEnter char to be deleted:");
    scanf("%*c%c", &ch);
    for(i=0; s[i]!='\0'; i++)
    {
        if(s[i]==ch)
        {
            for(j=i; s[j-1]!='\0'; j++)
            {
                s[j]=s[j+1];
            }
        }
    }
    printf("\nNew string=%s\n", s);
}
