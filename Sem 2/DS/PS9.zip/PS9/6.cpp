#include<iostream>
using namespace std;
class Node
{
        public:
        int data;
        Node* link;
};
void display(Node *Head)
{
    Node *temp;
    if(Head==NULL)
    {
        cout<<" ";
    }
    else
    {
        temp=Head;
        while(temp!=NULL)
        {
            cout<<temp->data<<" ";
            temp=temp->link;
        }

    }
    cout<<"\n";
}
void adjacency(int A[10][10], int n)
{
    int i, j;
    for(i=0; i<n; i++)
    {
        cout<<"\nRow "<<i+1<<":\n";
        for(j=0; j<n; j++)
        {
            cout<<"\nColumn "<<j+1<<":";
            cin>>A[i][j];
        }
    }
}
void conv(Node* AL[10], int A[10][10], int n)
{
    int i, j;
    Node *cur, *temp;
    for(i=0; i<n; i++)
    {
        temp=NULL;
        for(j=0; j<n; j++)
        {
            if(A[i][j]!=0)
            {
                cur=new Node;
                cur->data=j;
                cur->link=NULL;
                if(temp==NULL)
                {
                    AL[i]=cur;
                    temp=cur;
                }
                else
                {
                    temp->link=cur;
                    temp=cur;
                }
            }
        }
    }
    //conversion over
}
void disp(Node* AL[10], int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        cout<<i<<"-";
        display(AL[i]);
    }
}
int main()
{
    int A[10][10], n;
    cout<<"\nEnter number of nodes/vertices:";
    cin>>n;
    adjacency(A, n);
    Node* AL[10];
    conv(AL, A, n);
    disp(AL, n);
    return 0;
}
