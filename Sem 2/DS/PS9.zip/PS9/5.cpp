#include<iostream>
using namespace std;
class Node
{
        public:
        int data;
        Node* link;
};
void display(Node *Head)
{
    Node *temp;
    if(Head==NULL)
    {
        cout<<"\nList empty";
    }
    else
    {
        temp=Head;
        while(temp!=NULL)
        {
            cout<<temp->data<<"-->";
            temp=temp->link;
        }
        cout<<"END\n";
    }
}
Node* append(Node *Head) //a
{
        Node *temp, *cur= new Node;
        cout<<"\nEnter data:";
        cin>>cur->data;
        cur->link=NULL;
        if(Head==NULL)
        {
                Head=cur;
        }
        else
        {
                temp=Head;
                while(temp->link!=NULL)
                {
                        temp=temp->link;
                }
                temp->link=cur;
        }
        display(Head);
        return Head;
}
Node* SortedMerge(Node *Head1, Node *Head2)
{
    Node *Head3=NULL, *temp1=Head1, *temp2=Head2, *cur, *temp3=NULL;
    while((temp1!=NULL)&&(temp2!=NULL))
    {
        Node *cur=new Node;
        cur->link=NULL;
        if(temp3==NULL)
        {
            temp3=Head3=cur;
        }
        else
        {
            temp3->link=cur;
            temp3=cur;
        }
        if((temp1->data)<(temp2->data))
        {
            cur->data=temp1->data;
            temp1=temp1->link;
        }
        else
        {
            cur->data=temp2->data;
            temp2=temp2->link;
        }
    }
    while(temp1!=NULL)
    {
        cur=new Node;
        cur->data=temp1->data;
        cur->link=NULL;
        if(temp3==NULL)
        {
            Head3=temp3=cur;
        }
        else
        {
            temp3->link=cur;
            temp3=cur;
        }
        temp1=temp1->link;
    }
    while(temp2!=NULL)
    {
        cur=new Node;
        cur->data=temp2->data;
        cur->link=NULL;
        if(temp3==NULL)
        {
            Head3=temp3=cur;
        }
        else
        {
            temp3->link=cur;
            temp3=cur;
        }
        temp2=temp2->link;
    }
    display(Head3);
    return Head3;
}
int main()
{
    int ch, n;
    Node *Head1=NULL, *Head2=NULL, *Head3=NULL;
    do
    {
        cout<<"\.MENU:\n1.Append\n2.SortedMerge\n3.Display\n4.Exit\nEnter choice:";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        cout<<"\nEnter list no(1/2):";
                        cin>>n;
                        switch(n)
                        {
                            case 1: {
                                        Head1=append(Head1);
                                        break;
                                    }
                            case 2: {
                                        Head2=append(Head2);
                                        break;
                                    }
                            default:{
                                        cout<<"\nInvalid input";
                                        break;
                                    }
                        }
                        break;
                    }
            case 2: {
                        Head3=SortedMerge(Head1, Head2);
                        break;
                    }
            case 3: {
                        cout<<"\nEnter list no(1-3):";
                        cin>>n;
                        switch(n)
                        {
                            case 1: {
                                        display(Head1);
                                        break;
                                    }
                            case 2: {
                                        display(Head2);
                                        break;
                                    }
                            case 3: {
                                        display(Head3);
                                    }
                            default:{
                                        cout<<"\nInvalid input";
                                        break;
                                    }
                        }
                        break;
                    }
            case 4: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid input\n";
                    }
        }
    }while(ch!=4);

}
