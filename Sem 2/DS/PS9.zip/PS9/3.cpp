#include<iostream>
using namespace std;
class Node
{
        public:
        int data;
        Node* link;
};
void display(Node *Head)
{
    Node *temp;
    if(Head==NULL)
    {
        cout<<"\nList empty";
    }
    else
    {
        temp=Head;
        while(temp!=NULL)
        {
            cout<<temp->data<<"-->";
            temp=temp->link;
        }
        cout<<"END\n";
    }
}
Node* append(Node *Head) //a
{
        Node *temp, *cur= new Node;
        cout<<"\nEnter data:";
        cin>>cur->data;
        cur->link=NULL;
        if(Head==NULL)
        {
                Head=cur;
        }
        else
        {
                temp=Head;
                while(temp->link!=NULL)
                {
                        temp=temp->link;
                }
                temp->link=cur;
        }
        display(Head);
        return Head;
}
void AlternatingSplit(Node *Head)
{
    Node *temp1, *cur, *Head2=NULL, *Head3=NULL, *temp2=NULL, *temp3=NULL;
    bool f=true;
    temp1=Head;
    while(temp1!=NULL)
    {
        cur=new Node;
        cur->data=temp1->data;
        cur->link=NULL;
        if(f)
        {
            if(temp2==NULL)
            {
                temp2=Head2=cur;
            }
            else
            {
                temp2->link=cur;
                temp2=cur;
            }

            f=false;
        }
        else
        {
            if(temp3==NULL)
            {
                temp3=Head3=cur;
            }
            else
            {
                temp3->link=cur;
                temp3=cur;
            }
            f=true;
        }
        temp1=temp1->link;

    }
    display(Head2);
    display(Head3);
}
int main()
{
    Node *Head=NULL;
    int ch;
    do
    {
        cout<<"\nMENU:\n1. AlternatingSplit\n2.Display\n3.Append\n4. Exit\nEnter choice:";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        AlternatingSplit(Head);
                        break;
                    }
            case 2: {
                        display(Head);
                        break;
                    }
            case 3: {
                        Head=append(Head);
                        break;
                    }
            case 4: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid input\n";
                    }
        }
    }while(ch!=4);
}
