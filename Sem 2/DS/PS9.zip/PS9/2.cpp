#include<iostream>
using namespace std;
class Node
{
        public:
        int data;
        Node* link;
};
void display(Node *Head)
{
    Node *temp;
    if(Head==NULL)
    {
        cout<<"\nList empty";
    }
    else
    {
        temp=Head;
        while(temp!=NULL)
        {
            cout<<temp->data<<"-->";
            temp=temp->link;
        }
        cout<<"END\n";
    }
}
Node* append(Node *Head) //a
{
        Node *temp, *cur= new Node;
        cout<<"\nEnter data:";
        cin>>cur->data;
        cur->link=NULL;
       if(Head==NULL)
        {
                Head=cur;
        }
        else
        {
                temp=Head;
                while(temp->link!=NULL)
                {
                        temp=temp->link;
                }
                temp->link=cur;
        }
        display(Head);
        return Head;

}
Node* RemoveDuplicates(Node *Head)
{
    Node *temp=Head, *temp2;
    if(Head==NULL)
    {
        return Head;
    }
    while((temp->link)!=NULL)
    {
        if((temp->data)==(temp->link->data))
        {
            temp2=temp->link;
            temp->link=temp->link->link;
            delete temp2;
        }
        else
        {
            temp=temp->link;
        }
    }

    display(Head);
    return Head;
}
int main()
{
    Node *Head=NULL;
    int ch;
    do
    {
        cout<<"\nMENU\n1. Append\n2. RemoveDuplicates\n3. Display\n4. Exit\nEnter choice:";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        Head=append(Head);
                        break;
                    }
            case 2: {
                        Head=RemoveDuplicates(Head);
                        break;
                    }
            case 3: {
                        display(Head);
                        break;
                    }
            case 4: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid input\n";
                    }
        }
    }while(ch!=4);
    return 0;
}
