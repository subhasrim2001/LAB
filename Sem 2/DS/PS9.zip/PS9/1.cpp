#include<iostream>
using namespace std;
class Node
{
        public:
        int data;
        Node* link;
}*Head1=NULL, *Head2=NULL, *Head3=NULL;
void display(Node *Head)
{
    Node *temp;
    if(Head==NULL)
    {
        cout<<"\nList empty";
    }
    else
    {
        temp=Head;
        while(temp!=NULL)
        {
            cout<<temp->data<<"-->";
            temp=temp->link;
        }
        cout<<"END\n";
    }
}
int Count(Node *Head)//n
{
        int count=0;
        Node *temp=Head;
        while(temp!=NULL)
        {
                count++;
                temp=temp->link;
        }
        return count;
}
Node* append(Node *Head) //a
{
        Node *temp, *cur= new Node;
        cout<<"\nEnter data:";
        cin>>cur->data;
        cur->link=NULL;
        if(Head==NULL)
        {
                Head=cur;
        }
        else
        {
                temp=Head;
                while(temp->link!=NULL)
                {
                        temp=temp->link;
                }
                temp->link=cur;
        }
        display(Head);
        return Head;
}
void FrontBackSplit(Node *Head1, Node *Head2, Node *Head3)
{
    Node *temp, *temp2, *temp3;
    int n=Count(Head1);
    int cc=1;
    if(n==0)
    {
        Head2=NULL;
        Head3=NULL;
    }
    else if(n==1)
    {
        Head2=new Node;
        Head2->data=Head1->data;
        Head2->link=NULL;
        Head3=NULL;
    }
    else
    {
        temp=Head1;
        while(temp!=NULL)
        {
            temp2=new Node;
            temp2->data=temp->data;
            temp2->link=NULL;
            if(Head2==NULL)
            {
                Head2=temp3=temp2;
            }
            else
            {
                temp3->link=temp2;
                temp3=temp2;
            }
            temp=temp->link;
        }
        temp=Head2;
        if(n%2==0)
        {
            n=n/2;
        }
        else
        {
            n=(n/2)+1;
        }
        while(cc < n)
        {
            temp=temp->link;
            cc++;
        }
        Head3=temp->link;
        temp->link=NULL;
    }
    display(Head2);
    display(Head3);
}
Node* delete_last(Node *Head)//e
{
        Node *temp, *temp2;
        if(Head==NULL)
        {
                return Head;
        }
        else if(Head->link==NULL)
        {
                delete Head;
                Head=NULL;
        }
        else
        {
                temp=Head;
                while(temp->link->link!=NULL)
                {
                        temp=temp->link;
                }
                temp2=temp->link;
                temp->link=NULL;
                delete temp2;
        }
        display(Head);
        return Head;
}
int main()
{
    int ch;
    do
    {
        cout<<"\nMENU:\n1. Append\n2. Split\n3. Delete\n4. Exit\n";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        Head1=append(Head1);
                        break;
                    }
            case 2: {
                        FrontBackSplit(Head1, Head2, Head3);
                        break;
                    }
            case 3: {
                        delete_last(Head1);
                        break;
                    }
            case 4: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid input\n";
                    }
        }
    }while(ch!=4);
    return 0;
}
