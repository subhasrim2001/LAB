#include<iostream>
using namespace std;
class Stack
{
    int A[20];
    int top;
    public:
    Stack();
    static int size;
    int empty();
    void push(int );
    int pop();
    int popandtest(int &);
};
int Stack::popandtest(int &val)
{
    if(empty()==-1)
    {
        val=-1;
        return -1;
    }
    else
    {
        val=A[top];
        top--;
        return 0;
    }
}
int Stack::pop()
{
    int t;
    if(empty()==-1)
    {
        return -1;
    }
    else
    {
        t=A[top];
        top--;
        return t;
    }
}
void Stack::push(int num)
{
    if((top+1)==size)
    {

    }
    else
    {
        top++;
        A[top]=num;
    }
}
Stack::Stack()
{
    top=-1;
}
int Stack::size=20;
int Stack::empty()
{
    if(top==-1)
    {
        return -1;
    }
    else
    {
        return 0;
    }
}
int main()
{
    Stack S;
    int ch, s, f;
    do
    {
        cout<<"\nMENU:\n1.Push\n2.Pop\n3.Empty\n4.Popandtest\n5.Exit\nEnter choice:";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        cout<<"\nEnter number:";
                        cin>>s;
                        S.push(s);
                        break;
                    }
            case 2: {
                        s=S.pop();
                        if(s==-1)
                        {
                            cout<<"\nUnderflow\n";
                        }
                        else
                        {
                            cout<<"\n"<<s;
                        }
                        break;
                    }
            case 3: {
                        s=S.empty();
                        if(s==-1)
                        {
                            cout<<"\nEmpty\n";
                        }
                        else
                        {
                            cout<<"\nNot empty\n";
                        }
                        break;
                    }
            case 4: {
                        s=S.popandtest(f);
                        if(s==-1)
                        {
                            cout<<"\nUnderflow!!\n";
                        }
                        else
                        {
                            cout<<f<<"\n";
                        }
                        break;
                    }
            case 5: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid choice";
                        break;
                    }
        }
    }while(ch!=5);
    return 0;
}
