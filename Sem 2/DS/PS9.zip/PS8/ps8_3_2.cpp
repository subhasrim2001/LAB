#include<iostream>
using namespace std;
class Node
{
    public:
    int data;
    Node *link;
};
class Queue
{
    Node *front;
    Node *rear;
    public:
    Queue();
    int empty();
    void insert();
    int remove();
};
int Queue::remove()
{
    int t;
    Node *temp;
    if(front==NULL)
    {
        return -1;
    }
    else
    {
        t=front->data;
        temp=front;
        if(front==rear)
        {
            front=rear=NULL;
        }
        else
        {
            front=front->link;
        }
        delete temp;
        return t;
    }
}
Queue::Queue()
{
    front=rear=NULL;
}
int Queue::empty()
{
    if(front==NULL)
    {
        return -1;
    }
    return 0;
}
void Queue::insert()
{
    Node *cur=new Node;
    cout<<"\nEnter data:";
    cin>>cur->data;
    cur->link=NULL;
    if(front==NULL)
    {
        front=rear=cur;
    }
    else
    {
        rear->link=cur;
        rear=cur;
    }
}
int main()
{
    Queue Q1;
    int ch, num;
    do
    {
        cout<<"\nMENU:1.Empty\n2.Insert\n3.Delete\n4.Exit\nEnter ch:";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        num=Q1.empty();
                        if(num==-1)
                        {
                            cout<<"\nEmpty\n";
                        }
                        else
                        {
                            cout<<"\nNot empty\n";
                        }
                        break;
                    }
            case 2: {
                        Q1.insert();
                        break;
                    }
            case 3: {
                        num=Q1.remove();
                        if(num!=-1)
                        {
                            cout<<num<<endl;
                        }
                        else
                        {
                            cout<<"\nUnderflow!!";
                        }
                        break;
                    }
            case 4: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid input\n";
                    }
        }

    }while(ch!=4);
    return 0;
}
