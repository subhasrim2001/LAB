#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *link;
};
Node* push(Node* &top1)
{
    Node *cur=new Node;
    cout<<"\nEnter data:";
    cin>>cur->data;
    if(top1==NULL)
    {
        top1=cur;
        cur->link=NULL;
    }
    else
    {
        cur->link=top1;
        top1=cur;
    }
    return top1;
}
int empty(Node* &top1)
{
    if(top1==NULL)
    {
        return -1;
    }
    else
    {
        return 0;
    }
}
int popandtest(Node* &top1, int &f)
{
    Node *temp;
    if(empty(top1)==-1)
    {
        return -1;
    }
    else
    {
        f=top1->data;
        temp=top1;
        top1=top1->link;
        delete temp;
        return 0;
    }
}
int pop(Node* &top1)
{
    Node *temp;
    int t;
    if(empty(top1)==-1)
    {
        return -1;
    }
    else
    {
        t=top1->data;
        temp=top1;
        top1=top1->link;
        delete temp;
        return t;
    }
}
int main()
{
    Node *top1=NULL;
    int ch, s, f;
    do
    {
        cout<<"\nMENU:\n1.Push\n2.Pop\n3.Empty\n4.Popandtest\n5.Exit\nEnter choice:";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        top1=push(top1);
                        break;
                    }
            case 2: {
                        s=pop(top1);
                        if(s==-1)
                        {
                            cout<<"\nUnderflow\n";
                        }
                        else
                        {
                            cout<<"\n"<<s;
                        }
                        break;
                    }
            case 3: {
                        s=empty(top1);
                        if(s==-1)
                        {
                            cout<<"\nEmpty\n";
                        }
                        else
                        {
                            cout<<"\nNot empty\n";
                        }
                        break;
                    }
            case 4: {
                        s=popandtest(top1, f);
                        if(s==-1)
                        {
                            cout<<"\nUnderflow!!\n";
                        }
                        else
                        {
                            cout<<f<<"\n";
                        }
                        break;
                    }
            case 5: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid choice";
                        break;
                    }
        }
    }while(ch!=5);
    return 0;
}
