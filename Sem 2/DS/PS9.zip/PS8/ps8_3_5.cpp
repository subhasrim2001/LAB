#include<iostream>
using namespace std;
class Node
{
    public:
    int data;
    Node *link;
};
void interchange(Node *Head)
{
    Node *t1, *t2, *t3=Head;
    int p, q, count=0;
    if(Head==NULL)
    {
        return;
    }
    cout<<"\nEnter p, q:";
    cin>>p>>q;
    while(t3!=NULL)
    {
        count++;
        if(count==p)
        {
            t1=t3;
        }
        else if(count==q)
        {
            t2=t3;
        }
        t3=t3->link;
    }
    p=t1->data;
    t1->data=t2->data;
    t2->data=p;
};
void display(Node *Head)
{
    Node *temp;
    if(Head==NULL)
    {
        cout<<"\nList empty";
    }
    else
    {
        temp=Head;
        while(temp!=NULL)
        {
            cout<<temp->data<<"-->";
            temp=temp->link;
        }
        cout<<"END\n";
    }
}
Node* append(Node *Head) //a
{
        Node *temp, *cur= new Node;
        cout<<"\nEnter data:";
        cin>>cur->data;
        cur->link=NULL;
        if(Head==NULL)
        {
                Head=cur;
        }
        else
        {
                temp=Head;
                while(temp->link!=NULL)
                {
                        temp=temp->link;
                }
                temp->link=cur;
        }
        display(Head);
        return Head;
}
int main()
{
    do
    {
        cout<<"MENU:\n1.Insert\n2.Display\n3.Swap rth and nth elements\n4.Exit\nEnter choice:";
        cin>>ch;
    }while(ch!=4);
    return 0;
}
