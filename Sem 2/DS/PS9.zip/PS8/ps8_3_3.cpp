#include<iostream>
using namespace std;
class Node
{
    public:
    int data;
    Node *link;
};
int empty(Node *&Head)
{
    if(Head==NULL)
    {
        return -1;
    }
    return 0;
}
void pqinsert(Node *&Head)
{
    Node *cur=new Node;
    cout<<"\nEnter data:";
    cin>>cur->data;
    if(Head==NULL)
    {
        Head=cur;
        cur->link=NULL;
    }
    else
    {
        cur->link=Head;
        Head=cur;
    }
}
int pqmindelete(Node *&Head)
{
    int t;
    Node *temp, *prev;
    if(empty(Head)==-1)
    {
        return -1;
    }
    else if((Head->link)==NULL)
    {
        t=Head->data;
        delete Head;
        Head=NULL;
        return t;
    }
    else
    {
        temp=Head;
        t=Head->data;
        prev=NULL;
        while((temp->link)!=NULL)
        {
            if(t>(temp->link->data))
            {
                t=temp->link->data;
                prev=temp;
            }
            temp=temp->link;
        }
        if(prev==NULL) //head is the smallest
        {
            temp=Head;
            Head=Head->link;
            delete temp;
        }
        else
        {
            temp=prev->link;
            prev->link=prev->link->link;
            delete temp;
        }
        return t;
    }
}
int main()
{
    Node *Head=NULL;
    int ch, num;
    do
    {
        cout<<"\nMENU\n1.Empty\n2.Insert\n3. Delete min\n4. Exit\nEnter choice:";
        cin>>ch;
        switch(ch)
        {
            case 1: {
                        num=empty(Head);
                        if(num==-1)
                        {
                            cout<<"\nEmpty\n";
                        }
                        else
                        {
                            cout<<"\nNot empty\n";
                        }
                        break;
                    }
            case 2: {
                        pqinsert(Head);
                        break;
                    }
            case 3: {
                        num=pqmindelete(Head);
                        if(num==-1)
                        {
                            cout<<"\nEmpty\n";
                        }
                        else
                        {
                            cout<<num<<endl;
                        }
                        break;
                    }
            case 4: {
                        break;
                    }
            default:{
                        cout<<"\nInvalid input\n";
                    }
        }

    }while(ch!=4);
}
