#include"Country.h"
#include<iostream>
using namespace std;
void Country::read()
{
    cout<<"\nEnter name of country:";
    cin>>name;
    cout<<"\nEnter population:";
    cin>>pop;
    cout<<"\nEnter area:";
    cin>>area;
}
void Country::disp()
{
    cout<<"\nName:"<<name<<"\nPop:"<<pop<<"\nArea:"<<area<<endl;
}
float Country::r_area()
{
    return area;
}
int Country::r_pop()
{
    return pop;
}
