#include<iostream>
#include"Country.h"

using namespace std;

void lArea(Country C[], int n);
void lPop(Country C[], int n);
void lPopDen(Country C[], int n);
int main()
{
    Country C[5];
    int n, i;
    cout<<"\nEnter n:";
    cin>>n;
    for(i=0; i<n; i++)
    {
        C[i].read();
    }
    lArea(C, n);
    lPop(C, n);
    lPopDen(C, n);
    return 0;
}
void lArea(Country C[], int n)
{
    int i, l=0;
    for(i=0; i<n; i++)
    {
        if(C[l].r_area()<C[i].r_area())
        {
            l=i;
        }
    }
    cout<<"\nCountry with largest area"<<endl;
    C[l].disp();
}
void lPop(Country C[], int n)
{
    int i, l=0;
    for(i=0; i<n; i++)
    {
        if(C[l].r_pop()<C[i].r_pop())
        {
            l=i;
        }
    }
    cout<<"\nCountry with largest population"<<endl;
    C[l].disp();
}
void lPopDen(Country C[], int n)
{
    int i, l=0;
    float val1, val2;
    for(i=0; i<n; i++)
    {
        val1=C[l].r_pop()/C[l].r_area();
        val2=C[i].r_pop()/C[i].r_area();
        if(val1<val2)
        {
            l=i;
        }
    }
    cout<<"\nCountry with largest population density"<<endl;
    C[l].disp();
}
