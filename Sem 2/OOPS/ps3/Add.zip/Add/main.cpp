#include <iostream>
#include"Add.h"
using namespace std;

int main()
{
    Nos N[5], S;
    int n, i;
    cout<<"\nEnter n:";
    cin>>n;
    for(i=0; i<n; i++)
    {
        N[i].read();
    }
    for(i=0; i<n; i++)
    {
        S=N[i].add(S);
    }
    S.disp();
    return 0;
}
