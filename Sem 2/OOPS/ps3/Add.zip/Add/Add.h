#ifndef ADD_H_INCLUDED
#define ADD_H_INCLUDED

class Nos
{
    int x;
    public:
    Nos add(Nos N);
    void read();
    void disp();
    Nos();
};

#endif // ADD_H_INCLUDED
