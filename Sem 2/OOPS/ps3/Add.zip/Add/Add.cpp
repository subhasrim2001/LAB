#include<iostream>
#include"Add.h"
using namespace std;
void Nos::read()
{
    cout<<"\nEnter x:";
    cin>>x;
}
void Nos::disp()
{
    cout<<"\nx="<<x<<endl;
}
Nos::Nos()
{
    x=0;
}
Nos Nos::add(Nos N)
{
    Nos S;
    S.x=N.x+x;
    return S;
}
