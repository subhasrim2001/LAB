#include<iostream>
#include"Car.h"
using namespace std;
Car::Car(int s, int b, char c)
{
    engine_size=s;
    body_style=b;
    color_code=c;
}
Car::Car(const Car &C)
{
    engine_size=C.engine_size;
    body_style=C.body_style;
    color_code=C.color_code;
}
void Car::disp()
{
    cout<<"\nEngine size="<<engine_size<<endl;
    cout<<"\nBody Style="<<body_style<<endl;
    cout<<"\nColor Code="<<color_code<<endl;
}
