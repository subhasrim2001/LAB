#include <iostream>
#include "Car.h"
using namespace std;

int main()
{
    Car C1;
    C1.disp();
    Car C2(10, 2, 'Y');
    C2.disp();
    Car C3(C2);
    C3.disp();
    //cout << "Hello world!" << endl;
    return 0;
}
