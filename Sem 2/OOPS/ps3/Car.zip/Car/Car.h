#ifndef CAR_H_INCLUDED
#define CAR_H_INCLUDED

class Car
{
    int engine_size;
    int body_style;
    char color_code;
    public:
    Car(int =0, int =0, char ='X');
    void disp();
    Car(const Car &);
};
#endif // CAR_H_INCLUDED
