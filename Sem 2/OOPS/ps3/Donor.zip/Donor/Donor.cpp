#include<iostream>
#include"Donor.h"
char * Donor::r_bg()
{
        return blood_group;
}
int Donor::r_age()
{
        return age;
}
char Donor::r_sex()
{
        return sex;
}
