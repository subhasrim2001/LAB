#include"Address.h"
#include<iostream>
using namespace std;
void Address::read()
{
    cout<<"\nEnter door no:";
    cin>>dno;
    cout<<"\nEnter home name:";
    cin>>h_name;
    cout<<"\nEnter street name:";
    cin>>s_name;
    cout<<"\nEnter pincode:";
    cin>>pincode;
}
void Address::display()
{
    cout<<"\nDoor no:";
    cout<<dno;
    cout<<"\nHome name:";
    cout<<h_name;
    cout<<"\nStreet name:";
    cout<<s_name;
    cout<<"\nPincode:";
    cout<<pincode;
}
