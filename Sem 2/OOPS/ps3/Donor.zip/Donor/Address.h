#ifndef ADDRESS_H_INCLUDED
#define ADDRESS_H_INCLUDED

class Address
{
    int dno;
    char s_name[20];
    char d_name[20];
    long pincode;
    public:
    void read();
    void display();
};

#endif // ADDRESS_H_INCLUDED
