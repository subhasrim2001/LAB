#include <iostream>
#include"Coord.h"
using namespace std;
void convPol(Coord C);
int main()
{
    Coord C1(5.5, 6.6);
    double r, t;
    C1.display();
    convPol(C1);
    return 0;
}

