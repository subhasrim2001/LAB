#ifndef COORD_H_INCLUDED
#define COORD_H_INCLUDED

class Coord
{
    double xval;
    double yval;//rectangular co-ordinates
    public:
    Coord(double, double);
    void display();
    friend void convPol(Coord C);
};
#endif // COORD_H_INCLUDED
