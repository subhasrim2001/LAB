#include<iostream>
#include "Coord.h"
#include<math.h>
using namespace std;
Coord::Coord(double x, double y)
{
    xval=x;
    yval=y;
}
void Coord::display()
{
    cout<<"\nx="<<xval<<"\ny="<<yval<<endl;
}

void convPol(Coord C)
{
//    C.xval=r*cos(t);
//    C.yval=r*sin(t);
    cout<<pow((pow(C.xval, 2)+pow(C.yval, 2)), 0.5)<<endl;
    cout<<atan(C.yval/C.xval);
}
