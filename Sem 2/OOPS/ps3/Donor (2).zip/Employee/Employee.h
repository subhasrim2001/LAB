#ifndef EMPLOYEE_H_INCLUDED
#define EMPLOYEE_H_INCLUDED

class Employee
{
   char name[20];
   int employee_number;
   char designation[20];
   char location[20];
   int basicpay;
   static int no_of_emp;
   public:
   Employee();
   void input();
   void disp();
   static void d_no_of_emp();
   char * r_name();
   char * r_location();
};

#endif // EMPLOYEE_H_INCLUDED
