#include<iostream>
#include "Employee.h"
using namespace std;
int Employee::no_of_emp=0;
void Employee::input()
{
    cout<<"\nName:";
    cin>>name;
    cout<<"\nEmployee number:";
    cin>>employee_number;
    cout<<"\nDesignation:";
    cin>>designation;
    cout<<"\nLocation of Work Place:";
    cin>>location;
    cout<<"\nBasic Pay:";
    cin>>basicpay;
}
void Employee::disp()
{
    cout<<"\nName:";
    cout<<name;
    cout<<"\nEmployee number:";
    cout<<employee_number;
    cout<<"\nDesignation:";
    cout<<designation;
    cout<<"\nLocation of Work Place:";
    cout<<location;
    cout<<"\nBasic Pay:";
    cout<<basicpay;
}
char * Employee::r_name()
{
    return name;
}
char * Employee::r_location()
{
    return location;
}
Employee::Employee()
{
    no_of_emp++;
}
void Employee::d_no_of_emp()
{
    cout<<"\nNo of employees="<<no_of_emp<<endl;
}
