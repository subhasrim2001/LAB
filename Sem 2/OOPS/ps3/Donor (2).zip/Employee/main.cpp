#include <iostream>
#include<string.h>
#include"Employee.h"
using namespace std;
void search(Employee *, char nam[], char w[], int n);
int main()
{
    int n, i;
    char nam[20], work[20];
    cout<<"\nEnter n:";
    cin>>n;
    Employee *E = new Employee[n];
    for(i=0; i<n; i++)
    {
        E[i].input();
    }
    cout<<"\nSearching:";
    cout<<"\nEnter name:";
    cin>>nam;
    cout<<"\nEnter location of work place:";
    cin>>work;
    search(E, nam, work, n);
    E[0].d_no_of_emp();
    //cout << "Hello world!" << endl;
    return 0;
}
void search(Employee *E, char nam[], char w[], int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        if((strcmp(E[i].r_name(), nam)==0)&&(strcmp(E[i].r_location(), w)==0))
        {
            E[i].disp();
            break;
        }
    }
    if(i==n)
    {
        cout<<"\nNo Employee found\n";
    }
}
