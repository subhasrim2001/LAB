#include"Country_2.h"
#include<iostream>
using namespace std;
void Country::read()
{
    cout<<"\nEnter name of country:";
    cin>>name;
    cout<<"\nEnter population:";
    cin>>pop;
    cout<<"\nEnter area:";
    cin>>area;
}
void Country::disp()
{
    cout<<"\nName:"<<name<<"\nPop:"<<pop<<"\nArea:"<<area<<endl;
}
float Country::r_area()
{
    return area;
}
int Country::r_pop()
{
    return pop;
}
int Country::l_area(Country C)
{
    if(area>C.r_area())
    {
        return 0;
    }
    return 1;
}
int Country::l_pop(Country C)
{
    if(pop>C.r_pop())
    {
        return 0;
    }
    return 1;
}
int Country::l_popDen(Country C)
{
    if((pop/area)>(C.r_pop()/C.r_area()))
    {
        return 0;
    }
    return 1;
}
