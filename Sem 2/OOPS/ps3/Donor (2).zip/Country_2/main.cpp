#include <iostream>
#include"Country_2.h"
using namespace std;
int main()
{
    Country C[5];
    int n, i, k, l;
    cout<<"\nEnter n:";
    cin>>n;
    for(i=0; i<n; i++)
    {
        C[i].read();
    }
    k=C[0].l_area(C[1]);
    for(i=2; i<n; i++)
    {
        l=C[k].l_area(C[i]);
        if(l==1)
        {
            k=i;
        }
    }
    C[k].disp();
    k=C[0].l_pop(C[1]);
    for(i=2; i<n; i++)
    {
        l=C[k].l_pop(C[i]);
        if(l==1)
        {
            k=i;
        }
    }
    C[k].disp();
    k=C[0].l_popDen(C[1]);
    for(i=2; i<n; i++)
    {
        l=C[k].l_popDen(C[i]);
        if(l==1)
        {
            k=i;
        }
    }
    C[k].disp();
    return 0;
}
