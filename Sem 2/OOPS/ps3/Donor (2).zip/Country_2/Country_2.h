#ifndef COUNTRY_2_H_INCLUDED
#define COUNTRY_2_H_INCLUDED

class Country
{
    char name[20];
    int pop;
    float area;
    public:
    void read();
    void disp();
    int l_area(Country );
    int l_pop(Country );
    int l_popDen(Country );
    float r_area();
    int r_pop();
};

#endif // COUNTRY_2_H_INCLUDED
