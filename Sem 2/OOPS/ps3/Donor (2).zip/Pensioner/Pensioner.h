#ifndef PENSIONER_H_INCLUDED
#define PENSIONER_H_INCLUDED

class pensioner
{
    char name[20];
    int age;
    char gender;
    int social_security_no;
    int pension_amt;
    char support;
    public:
    void getdata();
    void isEligible();
    void print();
};
#endif // PENSIONER_H_INCLUDED
