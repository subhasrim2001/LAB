#include<iostream>
#include"Pensioner.h"
using namespace std;
void pensioner::getdata()
{
    cout<<"\nName:";
    cin>>name;
    cout<<"\nAge:";
    cin>>age;
    cout<<"\nGender(M/F):";
    cin>>gender;
    cout<<"\nSocial Security Number:";
    cin>>social_security_no;
    cout<<"\nPension Amount:";
    cin>>pension_amt;
    cout<<"\nSupport(Y/N)";
    cin>>support;
}
void pensioner::isEligible()
{
    if((pension_amt<1500)&&(support=='N'))
    {
        cout<<"\nEligible to avail discounts\n";
    }
    else
    {
        cout<<"\nIneligible to avail discounts\n";
    }
}
void pensioner::print()
{
    cout<<"\nName:";
    cout<<name;
    cout<<"\nAge:";
    cout<<age;
    cout<<"\nGender(M/F):";
    cout<<gender;
    cout<<"\nSocial Security Number:";
    cout<<social_security_no;
    cout<<"\nPension Amount:";
    cout<<pension_amt;
    cout<<"\nSupport(Y/N)";
    cout<<support;
}
