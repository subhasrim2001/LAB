#include <iostream>
#include"Pensioner.h"
using namespace std;

int main()
{
    pensioner P;
    cout<<"\nEnter details for pensioner:\n";
    P.getdata();
    P.isEligible();
    P.print();
    return 0;
}
