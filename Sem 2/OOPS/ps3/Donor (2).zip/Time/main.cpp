#include <iostream>
#include"Time.h"
using namespace std;

int main()
{
    int h, m, s;
    cout<<"\nEnter h, m, s for t1:";
    cin>>h>>m>>s;
    Time t1(h, m, s);
    cout<<"\nEnter h, m, s for t2:";
    cin>>h>>m>>s;
    Time t2(h, m, s);
    Time t3;
    t3=t1.add(t2);
    t3.disp();
    return 0;
}
