#ifndef TIME_H_INCLUDED
#define TIME_H_INCLUDED
class Time
{
    int hours;
    int minutes;
    int seconds;
    public:
    Time add(Time );
    Time(int =0, int =0, int =0);
    void disp();
};


#endif // TIME_H_INCLUDED
