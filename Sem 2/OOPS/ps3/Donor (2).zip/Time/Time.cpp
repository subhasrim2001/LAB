#include<iostream>
#include"Time.h"
using namespace std;
Time Time::add(Time t2)
{
    Time t3;
    t3.seconds=t2.seconds+seconds;
    t3.minutes=t3.seconds/60;
    t3.seconds=t3.seconds%60;
    t3.minutes+=t2.minutes+minutes;
    t3.hours=t3.minutes/60;
    t3.hours+=t2.hours+hours;
    if(t3.hours>24)
    {
        cout<<"\nHours>24:(";
        cout<<"\nConverting to less than 24:";
        t3.hours=t3.hours%24;
    }
    return t3;
}
Time::Time(int h, int m, int s)
{
    seconds=s%60;
    minutes=s/60;
    minutes+=m;
    hours=minutes/60;
    minutes=minutes%60;
    hours+=h;
    if(hours>24)
    {
        cout<<"\nHours greater than 24";
        cout<<"\nConverting to less than 24";
        hours=hours%24;
    }
}
void Time::disp()
{
    cout<<"\nHours="<<hours<<"\nMinutes="<<minutes<<"\nSeconds="<<seconds<<endl;
}
