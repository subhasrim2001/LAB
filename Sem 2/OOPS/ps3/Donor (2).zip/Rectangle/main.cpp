#include <iostream>
#include"Rectangle.h"
using namespace std;

int main()
{
    Rectangle R1;
    R1.set_b(5);
    R1.set_l(10);
    cout<<R1.get_b()<<endl<<R1.get_l()<<endl;
    cout<<R1.area()<<endl<<R1.Perimeter()<<endl;
    R1.disp();
    return 0;
}
