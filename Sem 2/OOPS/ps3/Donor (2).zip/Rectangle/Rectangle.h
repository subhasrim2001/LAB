#ifndef RECTANGLE_H_INCLUDED
#define RECTANGLE_H_INCLUDED
class Rectangle
{
    private:
    float length;
    float breadth;
    public:
    float area();
    float Perimeter();
    float get_l();
    void set_l(float fl);
    float get_b();
    void set_b(float fb);
    void disp();
};


#endif // RECTANGLE_H_INCLUDED
