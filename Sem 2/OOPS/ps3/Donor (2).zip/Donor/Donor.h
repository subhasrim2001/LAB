#ifndef DONOR_H_INCLUDED
#define DONOR_H_INCLUDED
#include"Address.h"
class Donor
{
    int dno;
    char dname[20];
    int age;
    Address A;
    char sex;
    char blood_group[4];
    public:
    void d_read();
    void d_disp();
    char * r_bg();
    int r_age();
    char r_sex();
};

#endif // DONOR_H_INCLUDED
