#include <iostream>
#include<string.h>
#include "Donor.h"
using namespace std;
void s_donors(char [], Donor *D, int n);
void s_donors(int min, int max, Donor *D, int n);
void s_donors(char [], int min, int max, Donor *D, int n);
int main()
{
    Donor D[10];
    int n, i, ch;
    cout<<"\nEnter n:";
    cin>>n;
    for(i=0; i<n; i++)
    {
        D[i].d_read();
    }
    cout<<"\nMenu:\n1. O+ blood\n2. 16 to 25\n3. Female donor of group A in the age between 19 and 24\n4. Exit\n";
    cout<<"Enter choice(1-4):";
    cin>>ch;
    switch(ch)
    {
        case 1: {
                    s_donors("O+", D, n);
                    break;
                }
        case 2: {
                    s_donors(16, 25, D, n);
                    break;
                }
        case 3: {
                    s_donors("A", 19, 24, D, n);
                    break;
                }
        case 4: {

                }
        default:{
                    cout<<"\nInvalid Input\n";
                }
    }
    return 0;
}
void s_donors(char b[], Donor *D, int n)
{
    int i;
    cout<<"\nDonor List:\n";
    for(i=0; i<n; i++)
    {
        if(strcmp(b, D[i].r_bg())==0)
        D[i].d_disp();
    }
}
void s_donors(int min, int max, Donor *D, int n)
{
    int i;
    cout<<"\nDonor list\n";
    for(i=0; i<n; i++)
    {
        if((D[i].r_age()>min)&&(D[i].r_age()<max))
        {
            D[i].d_disp();
        }
    }
}
void s_donors(char b[], int min, int max, Donor *D, int n)
{
    int i;
    cout<<"\nDonor list:\n";
    for(i=0; i<n; i++)
    {
        if((D[i].r_sex()=='F')&&(D[i].r_age()>min)&&(D[i].r_age()<max)&&(strcmp(b, D[i].r_bg())==0))
        {
                D[i].d_disp();
        }
    }
}

