#include<iostream>
#include"Donor.h"
#include"Address.h"
using namespace std;
char Donor::r_sex()
{
    return sex;
}
char * Donor::r_bg()
{
    return blood_group;
}
int Donor::r_age()
{
    return age;
}
void Donor::d_read()
{
    cout<<"\nDonor number:";
    cin>>dno;
    cout<<"\nDonor name:";
    cin>>dname;
    cout<<"\nAge:";
    cin>>age;
    cout<<"\nAddress";
    A.read();
    cout<<"\nEnter sex:";
    cin>>sex;
    cout<<"\nEnter blood group:";
    cin>>blood_group;
}
void Donor::d_disp()
{
    cout<<"\nDonor number:";
    cout<<dno;
    cout<<"\nDonor name:";
    cout<<dname;
    cout<<"\nAge:";
    cout<<age;
    cout<<"\nAddress";
    A.display();
    cout<<"\nSex:";
    cout<<sex;
    cout<<"\nBlood group:";
    cout<<blood_group;
}

