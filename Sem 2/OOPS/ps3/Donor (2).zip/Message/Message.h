#ifndef MESSAGE_H_INCLUDED
#define MESSAGE_H_INCLUDED
#include <time.h>
class Message
{
    char *sender;
    char *receiver;
    struct tm *ti;
    char *message;
    static int number;
    public:
    Message(char s[], char r[]);
    ~Message();
    void print();

};

#endif // MESSAGE_H_INCLUDED
