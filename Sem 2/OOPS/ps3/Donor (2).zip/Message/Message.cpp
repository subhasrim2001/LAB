#include<iostream>
#include"Message.h"
#include<time.h>
#include<string.h>
using namespace std;
int Message::number=0;
Message::Message(char s[], char r[])
{
    int l;
    l=strlen(s);
    sender=new char[l+1];
    l=strlen(r);
    receiver=new char[l+1];
    strcpy(sender, s);
    strcpy(receiver, r);
    time_t tt;
    tt=time(NULL);
    ti=localtime(&tt);
    number++;
}
void Message::print()
{
    cout<<"\nMessage Text:\n";
    cout<<"\nSender="<<sender;
    cout<<"\nReceiver="<<receiver;
    cout<<"\nTime="<<asctime(ti);
    cout<<"\nNumber of messages="<<number;
}
Message::~Message()
{
    delete[] sender;
    delete[] receiver;
}
