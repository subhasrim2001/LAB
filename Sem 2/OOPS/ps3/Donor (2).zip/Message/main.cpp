#include <iostream>
#include"Message.h"
using namespace std;

int main()
{
    char s[20], r[20];
    cout<<"\nEnter sender:";
    cin>>s;
    cout<<"\nEnter receiver:";
    cin>>r;
    Message M1(s, r);
    Message M2(r, s);
    M1.print();
    M2.print();
    //cout << "Hello world!" << endl;
    return 0;
}
