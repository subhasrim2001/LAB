#include <iostream>
#include"Rectangle.h"
#include"Block.h"
using namespace std;

int main()
{
    Rectangle R;
    Block B;
    int a;
    R.getdata();
    a=R.area();
    cout<<"\nArea="<<a<<endl;
    R.putdata();
    B.getdata();
    a=B.area();
    cout<<"\nBlock:"<<a<<endl;
    B.putdata();
    return 0;
}
