#ifndef RECTANGLE_H_INCLUDED
#define RECTANGLE_H_INCLUDED

class Rectangle
{
    int length;
    int width;
    public:
    void getdata();
    void putdata();
    int area();
};

#endif // RECTANGLE_H_INCLUDED
