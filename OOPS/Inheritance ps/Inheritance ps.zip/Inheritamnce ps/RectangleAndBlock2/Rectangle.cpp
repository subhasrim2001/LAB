#include<iostream>
#include"Rectangle.h"
using namespace std;
void Rectangle::getdata()
{
    cout<<"\nEnter length:";
    cin>>length;
    cout<<"\nEnter width:";
    cin>>width;
}
void Rectangle::putdata()
{
    cout<<"\nLength:"<<length<<"\nWidth:"<<width;
}
int Rectangle::area()
{
    return (length*width);
}
