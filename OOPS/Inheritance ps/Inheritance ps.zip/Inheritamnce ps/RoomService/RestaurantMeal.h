#ifndef RESTAURANTMEAL_H_INCLUDED
#define RESTAURANTMEAL_H_INCLUDED
#include<string>
using namespace std;
class RestaurantMeal
{
    string name;
    float price;
    public:
    RestaurantMeal(char []="\0", float =0.0);
    void display();
    float r_price();
};
#endif // RESTAURANTMEAL_H_INCLUDED
