#ifndef ROOMSERVICEMEAL_H_INCLUDED
#define ROOMSERVICEMEAL_H_INCLUDED
#include"RestaurantMeal.h"
#include"HotelService.h"
class RoomServiceMeal: public RestaurantMeal, public HotelService
{
    public:
    RoomServiceMeal(int =1000, char []="\0", float =0.0);
    void display();
};

#endif // ROOMSERVICEMEAL_H_INCLUDED
