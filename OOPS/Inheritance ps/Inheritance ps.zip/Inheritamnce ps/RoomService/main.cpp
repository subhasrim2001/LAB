#include <iostream>
#include"RoomServiceMeal.h"
using namespace std;

int main()
{
    RoomServiceMeal R(1202, "steak dinner", 19.99);
    R.display();
    return 0;
}
