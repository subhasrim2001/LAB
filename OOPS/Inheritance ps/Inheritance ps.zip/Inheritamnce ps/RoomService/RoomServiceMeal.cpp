#include<iostream>
#include"RoomServiceMeal.h"
RoomServiceMeal::RoomServiceMeal(int r, char n[], float p): RestaurantMeal(n, p), HotelService("room service", 4.00, r)
{

}
void RoomServiceMeal::display()
{
    HotelService::display();
    RestaurantMeal::display();
    cout<<"\nTotal:"<<r_price()+r_fee()<<endl;
}
