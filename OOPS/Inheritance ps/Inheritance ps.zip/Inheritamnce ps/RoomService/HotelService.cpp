#include<iostream>
#include"HotelService.h"
using namespace std;
HotelService::HotelService(char s[], float f, int r)
{
    service=s;
    fee=f;
    room=r;
}
float HotelService::r_fee()
{
    return fee;
}
void HotelService::display()
{
    cout<<"\nService:"<<service<<"\nFee:"<<fee<<"\nRoom:"<<room<<endl;
}
