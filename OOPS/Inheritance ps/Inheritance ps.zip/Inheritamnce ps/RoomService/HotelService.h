#ifndef HOTELSERVICE_H_INCLUDED
#define HOTELSERVICE_H_INCLUDED
#include<string>
using namespace std;
class HotelService
{
    string service;
    float fee;
    int room;
    public:
    float r_fee();
    HotelService(char []="\0", float =0.0, int =0);
    void display();
};
#endif // HOTELSERVICE_H_INCLUDED
