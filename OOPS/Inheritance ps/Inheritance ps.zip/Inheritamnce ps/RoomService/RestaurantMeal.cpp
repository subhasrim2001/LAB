#include<iostream>
#include"RestaurantMeal.h"
using namespace std;
RestaurantMeal::RestaurantMeal(char n[], float p)
{
    name=n;
    price=p;
}
void RestaurantMeal::display()
{
    cout<<"\nName:"<<name<<"\nPrice:"<<price<<endl;
}
float RestaurantMeal::r_price()
{
    return price;
}
