#include <iostream>
#include"Worker.h"
#include"Hourlyworker.h"
#include"Salariedworker.h"
using namespace std;

int main()
{
    Worker W(15, "subha");
    Hourlyworker H(1, "subha");
    Salariedworker S(2, "subha");
    Worker *Wp;
    Wp=&W;
    Wp->compute_pay(50);
    Wp=&H;
    Wp->compute_pay(50);
    Wp=&S;
    Wp->compute_pay(50);
    return 0;
}
