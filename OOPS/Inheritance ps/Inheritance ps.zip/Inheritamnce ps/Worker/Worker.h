#ifndef WORKER_H_INCLUDED
#define WORKER_H_INCLUDED
#include<string>
using namespace std;
class Worker
{
    string name;
    float rate;
    public:
    Worker(float, string);
    virtual void compute_pay(int);
    float r_rate();
};
#endif // WORKER_H_INCLUDED
