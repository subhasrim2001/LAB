#include<iostream>
#include"Worker.h"
using namespace std;
void Worker::compute_pay(int hours)
{
    cout<<"\nType of worker not specified!!!"<<endl;
}
Worker::Worker(float r, string n)
{
    name=n;
    rate=r;
}
float Worker::r_rate()
{
    return rate;
}
