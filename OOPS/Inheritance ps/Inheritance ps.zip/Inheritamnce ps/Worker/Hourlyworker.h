#ifndef HOURLYWORKER_H_INCLUDED
#define HOURLYWORKER_H_INCLUDED
#include"Worker.h"
class Hourlyworker: public Worker
{
    public:
    Hourlyworker(float, string);
    void compute_pay(int );
};

#endif // HOURLYWORKER_H_INCLUDED
