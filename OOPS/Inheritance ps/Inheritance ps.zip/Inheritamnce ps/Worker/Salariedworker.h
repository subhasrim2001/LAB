#ifndef SALARIEDWORKER_H_INCLUDED
#define SALARIEDWORKER_H_INCLUDED
#include"Worker.h"
class Salariedworker: public Worker
{
    public:
    Salariedworker(float, string);
    void compute_pay(int );
};
#endif // SALARIEDWORKER_H_INCLUDED
