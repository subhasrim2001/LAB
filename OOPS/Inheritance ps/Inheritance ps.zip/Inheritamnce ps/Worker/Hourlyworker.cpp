#include<iostream>
#include"Hourlyworker.h"
using namespace std;
void Hourlyworker::compute_pay(int hours)
{
    if(hours <=40)
    {
        cout<<"\nPay="<<hours*r_rate()<<endl;
    }
    else
    {
        cout<<"\nPay="<<(hours*r_rate())+(0.5*r_rate()*(40-hours))<<endl;
    }
}
Hourlyworker::Hourlyworker(float r, string n):Worker(r, n)
{

}
