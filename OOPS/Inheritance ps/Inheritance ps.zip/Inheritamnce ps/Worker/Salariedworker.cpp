#include"iostream"
#include"Salariedworker.h"
using namespace std;
void Salariedworker::compute_pay(int hours)
{
    cout<<"\nPay="<<hours*r_rate()<<endl;
}
Salariedworker::Salariedworker(float r, string n):Worker(r, n)
{

}
