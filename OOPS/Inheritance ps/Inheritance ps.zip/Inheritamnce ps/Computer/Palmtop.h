#ifndef PALMTOP_H_INCLUDED
#define PALMTOP_H_INCLUDED
#include"Computer.h"
#include"Laptop.h"
class PalmTop: public Laptop, virtual public Computer
{
        int widths;
        int height;
        public:
        PalmTop(int =0, int =0, int =0, int =0, string ="\0", int =0);
};
#endif // PALMTOP_H_INCLUDED
