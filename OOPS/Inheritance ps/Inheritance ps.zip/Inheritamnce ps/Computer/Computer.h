#ifndef COMPUTER_H_INCLUDED
#define COMPUTER_H_INCLUDED
#include<string>
using namespace std;
class Computer
{
    int size;
    string name;
    int address;
    public:
    Computer(int =0, string ="\0", int =0);
    friend void check(Computer *C);
};

#endif // COMPUTER_H_INCLUDED
