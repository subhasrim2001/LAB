#include<iostream>
#include"Laptop.h"
using namespace std;
Laptop::Laptop(int w, int s, string n, int a):Computer(s, n, a)
{
    weight=w;
}
