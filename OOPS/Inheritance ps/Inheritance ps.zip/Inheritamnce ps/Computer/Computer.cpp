#include<iostream>
#include"Computer.h"
using namespace std;
Computer::Computer(int s, string n, int a)
{
    size=s;
    name=n;
    address=a;
}
