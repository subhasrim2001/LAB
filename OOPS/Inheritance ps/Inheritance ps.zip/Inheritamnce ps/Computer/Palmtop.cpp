#include<iostream>
#include"Palmtop.h"
using namespace std;
PalmTop::PalmTop(int wi, int h, int w, int s, string n, int a):Computer(s, n, a), Laptop(w, s, n, a)
{
    widths=wi;
    height=h;
}
