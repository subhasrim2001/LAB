#include <iostream>
#include"Computer.h"
#include"Laptop.h"
#include"Palmtop.h"
using namespace std;

void check(Computer *ptr)
{
    if((ptr->address)!=0)
    {
        cout<<"\nAssigned";
    }
    else
    {
        cout<<"\nNot assigned";
    }
}
int main()
{
    Computer C(5, "subha");
    Laptop L(8, 5, "subha", 5);
    PalmTop P(8, 5, 9, 4, "subha", 6);
    check(&C);
    check(&L);
    check(&P);
    return 0;
}
