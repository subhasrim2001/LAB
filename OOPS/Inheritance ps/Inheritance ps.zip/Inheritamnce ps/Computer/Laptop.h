#ifndef LAPTOP_H_INCLUDED
#define LAPTOP_H_INCLUDED
#include"Computer.h"
class Laptop: virtual public Computer
{
    int weight;
    public:
    Laptop(int =0, int =0, string ="\0", int =0);

};
#endif // LAPTOP_H_INCLUDED
