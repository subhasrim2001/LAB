#include<iostream>
#include"CruiseShip.h"
using namespace std;
CruiseShip::CruiseShip(int m, char n[], char y[]):Ship(n, y)
{
    max=m;
}
int CruiseShip::r_max()
{
    return max;
}
void CruiseShip::m_max(int m)
{
    max=m;
}
void CruiseShip::print()
{
    cout<<"\nShip's Name:"<<r_name()<<"\nMaximum Passengers:"<<max<<endl;
}
