#include<iostream>
#include"Ship.h"
using namespace std;
Ship::Ship(char n[], char y[])
{
    name=n;
    year=y;
}
string Ship::r_name()
{
    return name;
}
string Ship::r_year()
{
    return year;
}
void Ship::m_name(string n)
{
    name=n;
}
void Ship::m_year(string y)
{
    year=y;
}
void Ship::print()
{
    cout<<"\nName:"<<name<<"\nYear:"<<year<<endl;
}
