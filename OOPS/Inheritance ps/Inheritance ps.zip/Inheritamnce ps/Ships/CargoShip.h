#ifndef CARGOSHIP_H_INCLUDED
#define CARGOSHIP_H_INCLUDED
#include"Ship.h"
class CargoShip: public Ship
{
    int capacity;
    public:
    CargoShip(int =0, char []="\0", char []="\0");
    int r_capacity();
    void m_capacity(int);
    void print();
};

#endif // CARGOSHIP_H_INCLUDED
