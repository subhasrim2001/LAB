#include <iostream>
#include"Ship.h"
#include"CruiseShip.h"
#include"CargoShip.h"
using namespace std;
int main()
{
    Ship *s;
    s=new Ship("hi", "hello");
    s->print();
    delete s;
    s=new CruiseShip(5, "hey", "hello");
    s->print();
    s=new CargoShip(5, "hey", "hello");
    s->print();
    return 0;
}
