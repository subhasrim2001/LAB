#ifndef CRUISESHIP_H_INCLUDED
#define CRUISESHIP_H_INCLUDED
#include"Ship.h"
class CruiseShip: public Ship
{
    int max;
    public:
    CruiseShip(int =0, char []="\0", char []="\0");
    int r_max();
    void m_max(int);
    void print();
};
#endif // CRUISESHIP_H_INCLUDED
