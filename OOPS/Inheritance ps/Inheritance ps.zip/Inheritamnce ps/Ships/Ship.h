#ifndef SHIP_H_INCLUDED
#define SHIP_H_INCLUDED
#include<string>
using namespace std;
class Ship
{
    string name;
    string year;
    public:
    Ship(char []="\0", char []="\0");
    string r_name();
    string r_year();
    void m_name(string );
    void m_year(string );
    virtual void print();
};
#endif // SHIP_H_INCLUDED
