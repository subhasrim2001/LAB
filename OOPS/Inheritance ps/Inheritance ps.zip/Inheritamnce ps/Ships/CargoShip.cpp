#include<iostream>
#include"CargoShip.h"
using namespace std;
CargoShip::CargoShip(int c, char n[], char y[]): Ship(n, y)
{
    capacity=c;
}
int CargoShip::r_capacity()
{
    return capacity;
}
void CargoShip::m_capacity(int c)
{
    capacity=c;
}
void CargoShip::print()
{
    cout<<"\nShip's Name:"<<r_name()<<"\nCapacity:"<<capacity<<endl;
}
