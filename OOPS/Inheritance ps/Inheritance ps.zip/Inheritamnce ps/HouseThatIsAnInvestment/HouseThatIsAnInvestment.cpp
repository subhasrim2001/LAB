#include"HouseThatIsAnInvestment.h"
#include<iostream>
using namespace std;
HouseThatIsAnInvestment::HouseThatIsAnInvestment(float i, float f, char s[], float feet):House(s, feet), Investment(i, f)
{

}
void HouseThatIsAnInvestment::display()
{
    House::display();
    Investment::display();
}
