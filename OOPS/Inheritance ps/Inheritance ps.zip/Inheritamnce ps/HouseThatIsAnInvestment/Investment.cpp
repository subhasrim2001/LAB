#include<iostream>
#include"Investment.h"
using namespace std;
Investment::Investment(int initial, int current)
{
    this->initial=initial;
    this->current=current;
    profit=current-initial;
    percentProfit=profit/initial;
}
void Investment::display()
{
    cout<<"\nInitial value:"<<initial<<"\nCurrent value:"<<current<<"\nProfit:"<<profit<<"\nPercent Profit:"<<percentProfit<<endl;
}
