#ifndef HOUSE_H_INCLUDED
#define HOUSE_H_INCLUDED
#include<string>
#include"Investment.h"
using namespace std;
class House
{
    string s;
    float feet;
    public:
    House(char []="\0", float = 0);
    void display();
};
#endif // HOUSE_H_INCLUDED

