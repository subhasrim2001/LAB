#include <iostream>
using namespace std;
#include"HouseThatIsAnInvestment.h"
int main()
{
    HouseThatIsAnInvestment H(1000, 1500, "rara", 1200);
    H.display();
    return 0;
}
