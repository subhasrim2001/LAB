#ifndef HOUSETHATISANINVESTMENT_H_INCLUDED
#define HOUSETHATISANINVESTMENT_H_INCLUDED
#include"House.h"
#include"Investment.h"
class HouseThatIsAnInvestment: public House, public Investment
{
    public:
    HouseThatIsAnInvestment(float =0, float =0, char []="\0", float =0);
    void display();
};
#endif // HOUSETHATISANINVESTMENT_H_INCLUDED
