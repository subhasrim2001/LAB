#ifndef INVESTMENT_H_INCLUDED
#define INVESTMENT_H_INCLUDED
class Investment
{
    float initial;
    float current;
    float profit;
    float percentProfit;
    public:
    Investment(int =0, int =0);
    void display();
};
#endif // INVESTMENT_H_INCLUDED
