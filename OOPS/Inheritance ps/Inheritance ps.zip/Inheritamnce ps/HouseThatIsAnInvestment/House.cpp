#include<iostream>
#include"House.h"
using namespace std;
House::House(char s[], float square)
{
    this->s=s;
    feet=square;
}
void House::display()
{
    cout<<"Street Addtress:"<<s<<"\nSquare Feet:"<<feet<<endl;
}

