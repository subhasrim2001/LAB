#include<iostream>
#include<string>
using namespace std;
class publication
{
    string title;
    float price;
    public:
    void getdata()
    {
        cin.ignore();
        cout<<"\nEnter title:";
        getline(cin, title);
        cout<<"\nEnter price:";
        cin>>price;
    }
    void putdata()
    {
        cout<<"\nTitle:"<<title<<"\nPrice:"<<price;
    }
};
class book: public publication
{
    int pageCount;
    public:
    void getdata()
    {
        publication::getdata();
        cout<<"\nEnter page count:";
        cin>>pageCount;
    }
    void putdata()
    {
        publication::putdata();
        cout<<"\nPage count:"<<pageCount;
    }
};
class tape: public publication
{
    float time;
    public:
    void getdata()
    {
        publication::getdata();
        cout<<"\nEnter tape playing time:";
        cin>>time;
    }
    void putdata()
    {
        publication::putdata();
        cout<<"\nTime:"<<time;
    }
};
int main()
{
    book B;
    B.getdata();
    B.putdata();
    tape T;
    T.getdata();
    T.putdata();
    return 0;

}
