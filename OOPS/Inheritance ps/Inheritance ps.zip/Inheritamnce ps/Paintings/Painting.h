#ifndef PAINTING_H_INCLUDED
#define PAINTING_H_INCLUDED
#include<string>
using namespace std;
class Painting
{
    string title;
    string name;
    int value;
    public:
    Painting(string="\0", string="\0", int =400);
    void display();
};
#endif // PAINTING_H_INCLUDED
