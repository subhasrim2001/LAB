#include<iostream>
#include"Painting.h"
using namespace std;
Painting::Painting(string t, string n, int v)
{
    title=t;
    name=n;
    value=v;
}
void Painting::display()
{
    cout<<"\nTitle:"<<title<<"\nName:"<<name<<"\nValue:"<<value<<endl;
}
