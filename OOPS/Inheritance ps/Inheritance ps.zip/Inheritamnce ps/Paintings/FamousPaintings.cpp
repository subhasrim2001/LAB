#include<iostream>
#include"FamousPaintings.h"
using namespace std;
FamousPainting::FamousPainting(string t, string n, int v): Painting(t, n, v)
{

}
