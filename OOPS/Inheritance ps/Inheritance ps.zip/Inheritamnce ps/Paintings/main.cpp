#include <iostream>
#include<string.h>
#include"Painting.h"
#include"FamousPaintings.h"
using namespace std;

int main()
{
    Painting *P[10];
    string a[4]={"Degas", "Monet", "Picasso", "Rembrandt"};
    int i, j;
    string t, n;
    for(i=0; i<10; i++)
    {
        cin.ignore();
        cout<<"\nEnter title:";
        getline(cin, t);
        cout<<"\nEnter artist name:";
        getline(cin, n);
        for(j=0; j<4; j++)
        {
            if(n==a[j])
            {
                FamousPainting F(t, n);
                P[i]=&F;
                break;
            }
        }
        if(j==4)
        {
            Painting Pa(t, n);
            P[i]=&Pa;
        }
    }
    for(i=0; i<10; i++)
    {
        P[i]->display();
    }
    return 0;
}
