#ifndef FAMOUSPAINTINGS_H_INCLUDED
#define FAMOUSPAINTINGS_H_INCLUDED
#include"Painting.h"
class FamousPainting: public Painting
{
    public:
    FamousPainting(string="\0", string="\0", int =25000);
};
#endif // FAMOUSPAINTINGS_H_INCLUDED
