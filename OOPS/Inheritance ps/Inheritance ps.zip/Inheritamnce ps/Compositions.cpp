#include<iostream>
#include<string>
#include<cstring>
using namespace std;
class MusicalComposition
{
    string title;
    string composer;
    int year;
    public:
    MusicalComposition(char []="\0", char []="\0", int =0);
    void display();
};
class NationalAnthem: public MusicalComposition
{
    string nation;
    public:
    NationalAnthem(char []="\0", char []="\0", char []="\0", int =0);
    void display();
};
void NationalAnthem::display()
{
    MusicalComposition::display();
    cout<<"\nNation:"<<nation<<endl;
}
NationalAnthem::NationalAnthem(char n[], char t[], char c[], int y): MusicalComposition(t, c, y)
{
    nation=n;
}
MusicalComposition::MusicalComposition(char t[], char c[], int y)
{
    title=t;
    composer=c;
    year=y;
}
void MusicalComposition::display()
{
    cout<<"\nTitle:"<<title<<"\nComposer:"<<composer<<"\nYear:"<<year<<endl;
}
int main()
{
    MusicalComposition M("raga", "me", 2020);
    M.display();
    NationalAnthem N("India", "Janaganamana", "Rabindranath Tagore", 1947);
    N.display();
}
