#ifndef BLOCK_H_INCLUDED
#define BLOCK_H_INCLUDED

#include"Rectangle.h"

class Block: public Rectangle
{
    int height;
    public:
    void getdata();
    void putdata();
};

#endif // BLOCK_H_INCLUDED
