#include <iostream>
#include"Rectangle.h"
#include"Block.h"
using namespace std;

int main()
{
    Rectangle R;
    Block B;
    R.getdata();
    R.putdata();
    B.getdata();
    B.putdata();

    return 0;
}
