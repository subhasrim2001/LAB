#include"Block.h"
#include<iostream>
using namespace std;
void Block::getdata()
{
    Rectangle::getdata();
    cout<<"\nEnter height:";
    cin>>height;
}
void Block::putdata()
{
    Rectangle::putdata();
    cout<<"\nHeight:"<<height;
}
