#include<iostream>
#include<string>
using namespace std;
class Book
{
    string title;
    string author;
    public:
    void getdata()
    {
        cin.ignore();
        cout<<"\nEnter title:";
        getline(cin, title);
        cout<<"\nEnter author:";
        getline(cin, author);
    }
    void putdata()
    {
        cout<<"\nTitle:"<<title<<"\nAuthor:"<<author<<endl;
    }
};
class Fiction:public Book
{
    int level;
    public:
    void getdata()
    {
        Book::getdata();
        cout<<"\nEnter level:";
        cin>>level;
    }
    void putdata()
    {
        Book::putdata();
        cout<<"\nLevel:"<<level;
    }
};
class NonFiction:public Book
{
    int pages;
    public:
    void getdata()
    {
        Book::getdata();
        cout<<"\nEnter pages:";
        cin>>pages;
    }
    void putdata()
    {
        Book::putdata();
        cout<<"\nPages:"<<pages;
    }
};
int main()
{
    Fiction F;
    NonFiction NF;
    cout<<"\nFiction:\n";
    F.getdata();
    F.putdata();
    cout<<"\nNon-fiction:\n";
    NF.getdata();
    NF.putdata();
    return 0;
}
