#include<iostream>
#include"Account.h"
#include<string.h>
#include<stdlib.h>
using namespace std;
Account::Account(int acno, char *n, int bal, char t)
{
    ac_number=acno;
    name=(char*)malloc(sizeof(n));
    strcpy(name, n);
    balance=bal;
    type=t;
}
int Account::checkmin()
{
    if(balance<1000)
    {
        return 0;
    }
    return 1;
}
void Account::deposit(int amt)
{
    balance+=amt;
}
void Account::withdraw(int amt)
{
    if(checkmin())
    {
        balance-=amt;
    }
    else
    {
        cout<<"\nWithdrawal not possible\nBalance too low\n";
    }
}
void Account::display()
{
    cout<<"Account Number:"<<ac_number<<"\nName:"<<name<<"\nType:"<<type<<"\nBalance:"<<balance<<endl;

}
Account::~Account()
{
    free(name);
}
