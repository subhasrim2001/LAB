#include <iostream>
#include "Account.h"

using namespace std;

int main()
{
    Account A(1, "ANI");
    A.deposit(100);
    A.withdraw(200);
    A.display();
    return 0;
}
