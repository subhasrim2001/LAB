#ifndef ACCOUNT_H_INCLUDED
#define ACCOUNT_H_INCLUDED

class Account
{
    int ac_number;
    char *name;
    char type;
    int balance;
    public:
    Account(int , char *, int =1000, char ='S');
    ~Account();
    void deposit(int);
    void withdraw(int);
    int checkmin();
    void display();
};
#endif // ACCOUNT_H_INCLUDED
