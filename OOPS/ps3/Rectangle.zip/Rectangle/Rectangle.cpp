#include"Rectangle.h"
#include<iostream>
using namespace std;
float Rectangle::area()
{
    return (length*breadth);
}
float Rectangle::get_b()
{
    return breadth;
}
float Rectangle::Perimeter()
{
    return (2*(length+breadth));
}
float Rectangle::get_l()
{
    return length;
}
void Rectangle::set_b(float fb)
{
    breadth=fb;
}
void Rectangle::set_l(float fl)
{
    length=fl;
}
void Rectangle::disp()
{
    cout<<"\nLength="<<length<<"\nBreadth="<<breadth<<endl;
}
