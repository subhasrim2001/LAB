#ifndef COUNTRY_H_INCLUDED
#define COUNTRY_H_INCLUDED

class Country
{
    char name[20];
    int pop;
    float area;
    public:
    void read();
    void disp();
    float r_area();
    int r_pop();
};
#endif // COUNTRY_H_INCLUDED
