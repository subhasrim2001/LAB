#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED

class Complex
{
    int real;
    int imag;
    public:
    Complex(int =0, int =0);
    void disp();
    friend void add(Complex &C3, Complex C2, Complex C1);
    friend void sub(Complex &C3, Complex C2, Complex C1);
    friend void mul(Complex &C3, Complex C2, Complex C1);
    ~Complex();
};

#endif // COMPLEX_H_INCLUDED
