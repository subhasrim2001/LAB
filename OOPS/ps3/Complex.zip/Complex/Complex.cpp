#include<iostream>
#include"Complex.h"
using namespace std;
void add(Complex &C3, Complex C2, Complex C1)
{
    C3.real=C2.real+C1.real;
    C3.imag=C2.imag+C1.imag;
}
void sub(Complex &C3, Complex C2, Complex C1)
{
    C3.real=C1.real-C2.real;
    C3.imag=C1.imag-C2.imag;
}
void mul(Complex &C3, Complex C2, Complex C1)
{
    C3.real=C2.real*C1.real;
    C3.imag=C2.imag*C1.imag;
}
Complex::Complex(int r, int i)
{
    real=r;
    imag=i;
}
Complex::~Complex()
{
    cout<<"\nMemory released";
}
void Complex::disp()
{
    cout<<"\nReal="<<real<<"\nImaginary="<<imag<<endl;
}
