#include <iostream>
#include "Complex.h"
using namespace std;

int main()
{
    int r, i;
    cout<<"\nEnter real and imaginary part of Complex number 1:";
    cin>>r>>i;
    Complex C1(r, i);
    cout<<"\nEnter real and imaginary part of Complex number 2:";
    cin>>r>>i;
    Complex C2(r, i);
    Complex C3;
    add(C3, C2, C1);
    C3.disp();
    sub(C3, C2, C1);
    C3.disp();
    mul(C3, C2, C1);
    C3.disp();
    //cout << "Hello world!" << endl;
    return 0;
}
